import sys, json, datetime, time, random

from twisted.internet import reactor
from autobahn.twisted.websocket import WebSocketClientProtocol
from duel.base.message_handler import MessageHandler

class ClientMessageHandler(MessageHandler):    
    def on_your_opponent_is(self):
        print 'Your opponent is', self.payload['data']
        self.client.loading()
    
    def on_start_playing(self):
        self.client.start_playing()
        
    def on_opponent_score(self):
        score = self.payload['score']
        answer = self.payload['answer']
        question_no = self.payload['question_no']
        print question_no, 'Op:', '(', answer, ')', score
        #self.client.opponent_last_score = score
        #self.client.game_ended()
    
    def on_game_ended(self):
        pass
        
    def on_ask_question(self):
        t = random.randint(0, 20)
        reactor.callLater(t + 2.5, self.sendMMM)
        self.t = t
    
    def sendMMM(self):
        answer = random.randint(0, 4)
        print self.payload['question_no'], 'Me:', '(', answer, ')', 20 - self.t
        if self.payload['answer'] == str(answer): 
            self.client.sendMessage({'code':'GQ', 'answer':answer, 'score':20 - self.t})
        
        
class DuelClientProtocol(WebSocketClientProtocol):
    """ Handle clinet side of a client connection
    """
    def onOpen(self):
        print 'Connected'
        self.send_wanna_play()
        
    def onPing(self, payload):
        pass
    
    def do_pong(self, payload=None):
        pass
        
    def onMessage(self, payload, isBinary):
        ClientMessageHandler(self, payload, isBinary)
    
    def sendMessage(self, payload, isBinary=False, fragmentSize=None, sync=False, doNotCompress=False):
        payload = json.dumps(payload)
        WebSocketClientProtocol.sendMessage(self, payload, isBinary=isBinary, fragmentSize=fragmentSize, sync=sync, doNotCompress=doNotCompress)

    def send_wanna_play(self):
        print 'Wanna Play'
        self.my_last_score = None
        self.opponent_last_score = None
        self.sendMessage({'code':'WP', 'category':1})
        
    def send_my_score(self, score, last=False):
        self.sendMessage({'code':'MS', 'score':score, 'last':last})
    
    def send_ready_to_play(self):
        print 'Ready to Play'
        self.sendMessage({'code':'RTP'})
        self.sendMessage({'code':'GQ', 'answer':-1, 'score':0})
        
    def loading(self):
        rand = random.randint(1,5)
        print 'wait for loading', rand
        time.sleep(rand)
        reactor.callLater(1, self.send_ready_to_play)
    
    def start_playing(self):
        self.local_score = 0
        
    def game_ended(self):
        if self.my_last_score is None or self.opponent_last_score is None:
            return
            
        if self.my_last_score < self.opponent_last_score:
            print 'YOU LOSE ...'
        elif self.my_last_score == self.opponent_last_score:
            print '... TIE ...'
        if self.my_last_score > self.opponent_last_score:
            print 'YOU WIN ...'
            
        reactor.callLater(1, self.onOpen)
    
    
    
    
    